from setuptools import setup, find_packages

setup(

    name='rotating_calipers',
    version='0.1',
    packages=find_packages(),
    install_requires=[],

)